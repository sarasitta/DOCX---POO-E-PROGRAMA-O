﻿namespace Docx___AvaliaçãoProgOOP
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.lbln1 = new System.Windows.Forms.Label();
            this.txtN1 = new System.Windows.Forms.TextBox();
            this.txtN2 = new System.Windows.Forms.TextBox();
            this.txtN3 = new System.Windows.Forms.TextBox();
            this.lbln2 = new System.Windows.Forms.Label();
            this.lbln3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblMed = new System.Windows.Forms.Label();
            this.txtmed = new System.Windows.Forms.TextBox();
            this.lblResult = new System.Windows.Forms.Label();
            this.btcCalc = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(89, 39);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(199, 20);
            this.txtNome.TabIndex = 0;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(23, 42);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(38, 13);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome:";
            // 
            // lbln1
            // 
            this.lbln1.AutoSize = true;
            this.lbln1.Location = new System.Drawing.Point(23, 72);
            this.lbln1.Name = "lbln1";
            this.lbln1.Size = new System.Drawing.Size(42, 13);
            this.lbln1.TabIndex = 2;
            this.lbln1.Text = "Nota 1:";
            // 
            // txtN1
            // 
            this.txtN1.Location = new System.Drawing.Point(89, 70);
            this.txtN1.Name = "txtN1";
            this.txtN1.Size = new System.Drawing.Size(84, 20);
            this.txtN1.TabIndex = 3;
            // 
            // txtN2
            // 
            this.txtN2.Location = new System.Drawing.Point(89, 101);
            this.txtN2.Name = "txtN2";
            this.txtN2.Size = new System.Drawing.Size(84, 20);
            this.txtN2.TabIndex = 4;
            // 
            // txtN3
            // 
            this.txtN3.Location = new System.Drawing.Point(89, 167);
            this.txtN3.Name = "txtN3";
            this.txtN3.Size = new System.Drawing.Size(84, 20);
            this.txtN3.TabIndex = 5;
            this.txtN3.Visible = false;
            // 
            // lbln2
            // 
            this.lbln2.AutoSize = true;
            this.lbln2.Location = new System.Drawing.Point(23, 102);
            this.lbln2.Name = "lbln2";
            this.lbln2.Size = new System.Drawing.Size(42, 13);
            this.lbln2.TabIndex = 6;
            this.lbln2.Text = "Nota 2:";
            // 
            // lbln3
            // 
            this.lbln3.AutoSize = true;
            this.lbln3.Location = new System.Drawing.Point(23, 170);
            this.lbln3.Name = "lbln3";
            this.lbln3.Size = new System.Drawing.Size(42, 13);
            this.lbln3.TabIndex = 7;
            this.lbln3.Text = "Nota 3:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(70, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Nota do Aluno";
            // 
            // lblMed
            // 
            this.lblMed.AutoSize = true;
            this.lblMed.Location = new System.Drawing.Point(208, 72);
            this.lblMed.Name = "lblMed";
            this.lblMed.Size = new System.Drawing.Size(39, 13);
            this.lblMed.TabIndex = 9;
            this.lblMed.Text = "Média:";
            // 
            // txtmed
            // 
            this.txtmed.Location = new System.Drawing.Point(249, 69);
            this.txtmed.Name = "txtmed";
            this.txtmed.Size = new System.Drawing.Size(84, 20);
            this.txtmed.TabIndex = 11;
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Location = new System.Drawing.Point(253, 101);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(0, 13);
            this.lblResult.TabIndex = 12;
            // 
            // btcCalc
            // 
            this.btcCalc.Location = new System.Drawing.Point(258, 208);
            this.btcCalc.Name = "btcCalc";
            this.btcCalc.Size = new System.Drawing.Size(75, 23);
            this.btcCalc.TabIndex = 13;
            this.btcCalc.Text = "Calcular Nota:";
            this.btcCalc.UseVisualStyleBackColor = true;
            this.btcCalc.Click += new System.EventHandler(this.btcCalc_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(26, 208);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpar.TabIndex = 14;
            this.btnLimpar.Text = "Limpar:";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(358, 258);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btcCalc);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.txtmed);
            this.Controls.Add(this.lblMed);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbln3);
            this.Controls.Add(this.lbln2);
            this.Controls.Add(this.txtN3);
            this.Controls.Add(this.txtN2);
            this.Controls.Add(this.txtN1);
            this.Controls.Add(this.lbln1);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.txtNome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lbln1;
        private System.Windows.Forms.TextBox txtN1;
        private System.Windows.Forms.TextBox txtN2;
        private System.Windows.Forms.TextBox txtN3;
        private System.Windows.Forms.Label lbln2;
        private System.Windows.Forms.Label lbln3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblMed;
        private System.Windows.Forms.TextBox txtmed;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Button btcCalc;
        private System.Windows.Forms.Button btnLimpar;
    }
}

