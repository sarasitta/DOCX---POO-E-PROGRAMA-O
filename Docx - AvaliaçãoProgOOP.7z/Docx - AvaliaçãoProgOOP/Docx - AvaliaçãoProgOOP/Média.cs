﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Docx___AvaliaçãoProgOOP
{
    //Classe
    class Média
    {
        //variavéis e declaração de variáveis
        public float nota1, nota2, rec, media;
        

        //métodos
        public Média(float n1, float n2, float r, float m) 
        {
            this.nota1 = n1;
            this.nota2 = n2;
            this.rec = r;
            this.media = m;
        }

        //Métodos e Funções
        public float calc(float n1, float n2, float m) 
        {
            m = (n1 + n2) /2 ;
            return m;
        }

        public float calcrec(float n1, float n2, float r, float m)
        {
            m = (n1 + n2 + r) / 3;
            return m;
        }
    }
}
