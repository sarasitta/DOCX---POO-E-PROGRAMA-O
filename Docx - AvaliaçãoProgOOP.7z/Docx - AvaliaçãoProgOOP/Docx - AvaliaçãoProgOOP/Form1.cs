﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Docx___AvaliaçãoProgOOP
{
    public partial class Form1 : Form
    {
        //Métodos
        void Limpar()
        {
            txtN1.Clear();
            txtN2.Clear();
            txtN3.Clear();
            txtmed.Clear();
            txtNome.Clear();
            txtmed.Focus();
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void btcCalc_Click(object sender, EventArgs e)
        {
           Média MedObj = new Média(float.Parse(txtN1.Text), float.Parse(txtN2.Text), float.Parse(txtN3.Text), float.Parse(txtmed.Text));

            //Exceção - trycatch
            try
           { 
                //Estrutura de Decisão
                if (MedObj.media < 5)
                {
                    txtmed.Text = Convert.ToString(MedObj.calcrec(float.Parse(txtN1.Text), float.Parse(txtN2.Text), float.Parse(txtN3.Text), float.Parse(txtmed.Text)));
                    lblResult.Text = "Reprovado.";
                    txtN3.Visible = true;
                }
                else
                {
                    txtmed.Text = Convert.ToString(MedObj.calc(float.Parse(txtN1.Text), float.Parse(txtN2.Text), float.Parse(txtmed.Text)));
                    lblResult.Text = "Aprovado.";
                }
                
            }
            catch (Exception)
            {
                if(string.IsNullOrWhiteSpace(txtN1.Text) && string.IsNullOrWhiteSpace(txtN2.Text) && string.IsNullOrWhiteSpace(txtN1.Text))
                {
                    MessageBox.Show("Preencha os campos com as notas!");
                }
            }

        }
        
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            Limpar();
        }
    }
}
